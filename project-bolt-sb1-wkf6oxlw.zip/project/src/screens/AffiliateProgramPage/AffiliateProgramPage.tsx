import React from "react";
import { Link } from "react-router-dom";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { UserPlus, Share2, Gift } from "lucide-react";
const logowhite = 'https://raw.githubusercontent.com/Etherlabs-dev/studypalassets/refs/heads/main/2.png'
const logoblack = 'https://raw.githubusercontent.com/Etherlabs-dev/studypalassets/refs/heads/main/1.png'
const handshakeimg = 'https://raw.githubusercontent.com/Etherlabs-dev/studypalassets/refs/heads/main/affiliate-handshake-2.png'
const affiliatewoman = 'https://raw.githubusercontent.com/Etherlabs-dev/studypalassets/refs/heads/main/affiliate-woman.png'
// FAQ data
const faqs = [
  {
    question: "Is there a free trial available?",
    answer: "Yes, you can try us for free for 30 days. If you want, we'll provide you with a free, personalized 30-minute onboarding call to get you up and running as soon as possible.",
  },
  {
    question: "Can I change my plan later?",
    answer: "Yes, you can upgrade or downgrade your plan at any time through your account settings.",
  },
  {
    question: "What is your cancellation policy?",
    answer: "You can cancel your subscription anytime. We'll refund you the remaining days of your billing period.",
  },
  {
    question: "Can other info be added to an invoice?",
    answer: "Yes, you can add custom information to your invoices including your business details and tax ID.",
  },
  {
    question: "How does billing work?",
    answer: "We offer both monthly and annual billing options. Choose the plan that works best for you.",
  },
  {
    question: "How do I change my account email?",
    answer: "You can change your email address anytime through your account settings page.",
  },
];

// Steps data
const steps = [
  {
    title: "Register and Get Approved",
    description: "Sign up as an affiliate and gain access to your unique referral tools with ease.",
    icon: UserPlus,
  },
  {
    title: "Share Your Referral Link",
    description: "Promote Study Pal using your custom link to drive sign-ups and purchases seamlessly.",
    icon: Share2,
  },
  {
    title: "Earn Commissions",
    description: "Receive commissions for each successful referral, tracked in real-time on your affiliate dashboard.",
    icon: Gift,
  },
];

export const AffiliateProgramPage = (): JSX.Element => {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="w-full bg-white border-b border-gray-200">
        <div className="container mx-auto px-4 py-4">
          <nav className="flex items-center justify-between">
            <Link to="/">
              <img src={logoblack} className="h-8" />
            </Link>
            <div className="hidden md:flex items-center space-x-8">
              <Link to="#" className="text-gray-600 hover:text-gray-900">About Us</Link>
              <Link to="#" className="text-gray-600 hover:text-gray-900">Pricing</Link>
              <Link to="/blogs" className="text-gray-600 hover:text-gray-900">Blogs</Link>
              <Link to="/affiliate-program" className="text-gray-600 hover:text-gray-900">Affiliate Program</Link>
              <Link to="/contact" className="text-gray-600 hover:text-gray-900">Contact Us</Link>
              <Link to="/marking-service" className="text-gray-600 hover:text-gray-900">Marking Services</Link>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="outline" className="border-primary-500 text-primary-500">
                Sign Up
              </Button>
              <Button className="bg-primary-500 text-white">
                Sign In
              </Button>
            </div>
          </nav>
        </div>
      </header>

      {/* Breadcrumb */}
      <div className="bg-gray-50 py-4">
        <div className="container mx-auto px-4">
          <div className="flex items-center space-x-2 text-sm">
            <Link to="/" className="text-primary-500 hover:underline">Home</Link>
            <span className="text-gray-400">→</span>
            <span className="text-gray-600">Affiliate Program</span>
          </div>
        </div>
      </div>

      {/* Hero Section */}
      <div className="p-8">
        <section className="bg-[#4285F4] text-white rounded-2xl overflow-hidden relative">
          <div className="container mx-auto px-8 pt-16 pb-32 md:pb-16">
            <div className="flex flex-col md:flex-row items-center gap-12">
              <div className="md:w-1/2 z-10">
                <div className="bg-[#EFF5FF] text-[#4285F4] inline-block px-4 py-2 rounded-full mb-6">
                  Join Us Now
                </div>
                <h1 className="text-4xl md:text-5xl font-bold mb-6">
                  Partner with Us and Earn Rewards
                </h1>
                <p className="text-lg mb-8 text-white/90">
                  Join our affiliate program, share the benefits of Study Pal, and earn commissions effortlessly.
                </p>
                <div className="flex gap-4">
                  <button 
                    className="bg-white rounded-sm text-[#4285F4] hover:bg-gray-100 h-10 px-4 text-sm"
                  >
                    Sign Up Now
                  </button>
                  <button 
                    variant="outline" 
                    className="border rounded-sm  border-white text-white h-10 px-4 text-sm"
                  >
                    Learn more
                  </button>
                </div>
              </div>
              <div className="md:w-1/2 absolute bottom-0 right-0 md:relative">
                <img 
                  src={affiliatewoman}
                  alt="Happy affiliate partner showing phone and gift" 
                  className="w-full"
                />
              </div>
            </div>
          </div>
        </section>
      </div>

      {/* About Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center gap-12">
            <div className="md:w-1/2">
              <div className="relative rounded-lg overflow-hidden">
                <img 
                  src={handshakeimg}
                  alt="About Affiliate Program"
                  className="w-full h-auto"
                />
              </div>
            </div>
            <div className="md:w-1/2">
              <h2 className="text-3xl font-bold mb-6">About our Affiliate Program</h2>
              <p className="text-gray-600">
                Looking to join our fast-growing affiliate program while advocating for better education? You're in the right place! Our program offers competitive commissions, dedicated support, and powerful tools to help you succeed.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Steps Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 text-center">
          <div className="inline-block bg-blue-50 text-[#4285F4] px-4 py-2 rounded-full mb-6">
            How it Works
          </div>
          <h2 className="text-3xl font-bold mb-4">Simple Steps to Get Started</h2>
          <p className="text-gray-600 mb-12">Three easy steps to start earning today.</p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {steps.map((step, index) => (
              <div key={index} className="bg-white p-8 rounded-lg shadow-sm">
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center mb-6 mx-auto ${
                  index === 0 ? 'bg-blue-50' :
                  index === 1 ? 'bg-orange-50' :
                  'bg-green-50'
                }`}>
                  {React.createElement(step.icon, {
                    className: `w-6 h-6 ${
                      index === 0 ? 'text-blue-500' :
                      index === 1 ? 'text-orange-500' :
                      'text-green-500'
                    }`
                  })}
                </div>
                <h3 className="text-xl font-semibold mb-4">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="inline-block bg-blue-50 text-[#4285F4] px-4 py-2 rounded-full mb-6">
            FAQ's
          </div>
          <h2 className="text-3xl font-bold mb-4">Frequently Asked Questions</h2>
          <p className="text-gray-600 mb-12">Find answers to common queries and learn how to make the most of our tools and features.</p>
          
          <div className="max-w-3xl mx-auto">
            <div className="space-y-4">
              {faqs.map((faq, index) => (
                <div key={index} className="bg-gray-50 p-6 rounded-lg">
                  <button className="flex justify-between items-center w-full text-left">
                    <h3 className="text-lg font-semibold">{faq.question}</h3>
                    <svg className="w-6 h-6 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>
                  <p className="mt-2 text-gray-600">{faq.answer}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black text-white py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1">
              <img src={logowhite} className="h-12 mb-6" />
              <p className="text-gray-400">
                Helping students learn better, write smarter, and achieve more with powerful AI academic tools.
              </p>
            </div>
            <div>
              <h3 className="text-sm font-medium mb-4">Quick Links</h3>
              <ul className="space-y-3">
                <li><Link to="#" className="text-gray-400 hover:text-white">About Us</Link></li>
                <li><Link to="#" className="text-gray-400 hover:text-white">Pricing</Link></li>
                <li><Link to="/blogs" className="text-gray-400 hover:text-white">Blogs</Link></li>
                <li><Link to="/affiliate-program" className="text-gray-400 hover:text-white">Affiliate Program</Link></li>
                <li><Link to="#" className="text-gray-400 hover:text-white">Contact Us</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-sm font-medium mb-4">Writing Tools</h3>
              <ul className="space-y-3">
                <li><Link to="#" className="text-gray-400 hover:text-white">Assignment Feedback</Link></li>
                <li><Link to="#" className="text-gray-400 hover:text-white">Paraphrasing</Link></li>
                <li><Link to="#" className="text-gray-400 hover:text-white">Grammar Checker</Link></li>
                <li><Link to="#" className="text-gray-400 hover:text-white">Outline Generator</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-sm font-medium mb-4">Stay up to date</h3>
              <div className="flex gap-4">
                <Input
                  type="email"
                  placeholder="Enter your email"
                  className="bg-white text-black"
                />
                <Button className="bg-primary-500">
                  Subscribe
                </Button>
              </div>
            </div>
          </div>
          <div className="mt-12 pt-8 border-t border-gray-800">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <p className="text-gray-400">© 2077 My Study Pal. All rights reserved.</p>
              <div className="flex space-x-6 mt-4 md:mt-0">
                <Link to="/terms" className="text-gray-400 hover:text-white">Terms</Link>
                <Link to="/privacy" className="text-gray-400 hover:text-white">Privacy</Link>
                <Link to="/cookies" className="text-gray-400 hover:text-white">Cookies</Link>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};